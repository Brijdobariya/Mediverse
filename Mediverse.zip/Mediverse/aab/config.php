<?php
    $connection = mysqli_connect("localhost", "root", "", "edoc"); // Establishing Connection with Server
    if(!$connection){
        echo "<script type='text/javascript'>alert('Not Connected! Server Problem...')</script>";

    }    
?>